
module Prova1 {
	requires java.sql;
}